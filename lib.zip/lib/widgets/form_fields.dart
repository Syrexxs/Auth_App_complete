import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {
  final TextEditingController controller;
  final String labelText;
  final IconData prefixIcon;
  final TextInputType keyboardType;
  final String? Function(String?) validator;

  const CustomTextFormField({
    Key? key,
    required this.controller,
    required this.labelText,
    required this.prefixIcon,
    this.keyboardType = TextInputType.text,
    required this.validator,
  }) : super(key: key);


  @override
  Widget build(BuildContext context){
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        border: const OutlineInputBorder(),
        prefixIcon: Icon(prefixIcon),
      ),
      keyboardType: keyboardType,
      validator: validator,
    );
  }
}

class GenderSection extends StatelessWidget {
  final String selectedGender;
  final Function(String) onchange;

  const GenderSection({
    Key? key,
    required this.selectedGender,
    required this.onchange,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color:  Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text (
            'Gender',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: GenderOption(
                  label: 'Male',
                  icon: Icons.male,
                  isSelected: selectedGender == 'Male',
                  onTap: () => onchange('Male'),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: GenderOption(
                  label: 'Female',
                  icon: Icons.female,
                  isSelected: selectedGender == 'Female',
                  onTap: () => onchange('Female'),
                ),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class GenderOption extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const GenderOption({
    Key? key,
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
    );
  }
}
import 'package:flutter/material.dart';
import 'screens/form_screen.dart';

void main(){
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key ? key}) : super (key: key);

  // const make the constructor constant, immutable, reusable when nothing changes
  //({Key ? key}) named constructor with an optional key parameter
  // key help the flutter to identify and preserve widgets during rebuilds
  //super (key: key); passes the key up to the superclasses (StatelessWidget)

   @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Form Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home : const FormScreen(),
    );
  }

}